//
//  UIImageForCell.h
//  Sprawl
//
//  Created by George Williams on 9/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIImageForCell : NSObject 
{
    
}

@property (nonatomic, retain) UIImage   *img;
@property (nonatomic, retain) NSNumber  *idx;

@end
