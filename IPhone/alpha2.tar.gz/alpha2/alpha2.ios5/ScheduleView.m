//
//  ScheduleView.m
//  alpha2
//
//  Created by George Williams on 12/23/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ScheduleView.h"
#import "Utility.h"
#import "alpha2AppDelegate.h"
 
@implementation ScheduleView 

@synthesize tv=_tv;
@synthesize djname=_djname;
@synthesize djid=_djid;
@synthesize schedule=_schedule;
@synthesize activity=_activity;
@synthesize api=_api;
@synthesize label_title=_label_title;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) 
    {
        self.api = [ [ [ DJCAPI alloc ] init:self ] autorelease ];
    }
    return self;
}

- (id) init
{
    return [ self initWithNibName:@"ScheduleView" bundle:nil];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void) viewWillAppear:(BOOL)animated
{
    [ super viewWillAppear:animated];
    
    self.schedule = nil;
    self.tv.hidden = YES;
    self.activity.hidden = NO;
    
    NSString *title = [ NSString stringWithFormat:@"Schedule for %@", self.djname ];
    self.label_title.text = title;
}


-(void) viewDidAppear:(BOOL)animated
{
    [ super viewDidAppear:animated];
    
    if ( ! [ self.api get_schedule:self.djid ] )
    {
        [ Utility AlertAPICallFailed ];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tv.delegate = self;
    self.tv.dataSource = self;
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void) dealloc
{
    self.djname = nil;
    self.djid = nil;
    self.schedule = nil;
    self.api = nil;
    
    [ super dealloc ];
}


#pragma mark - table view delegates...



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ( self.schedule == nil )
    {
        return 1;
    }
    else if ( [ self.schedule count ] == 0 )
    {
        return 1;
    }
    else
    {
        return [ self.schedule count ];
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger row = [ indexPath row ];
    
    [ self.tv deselectRowAtIndexPath:indexPath animated:YES ];
    
    NSDictionary *item = [ self.schedule objectAtIndex:row ];
    
    NSString *eid = [ item objectForKey:@"eid" ];
    
    alpha2AppDelegate *app = ( alpha2AppDelegate *)
        [[ UIApplication sharedApplication ] delegate ];
    [ app showEventModal:self :nil :eid];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ( self.schedule == nil )
    {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:
                                 @"plain_cell"];
        if (cell == nil) 
        {
            cell = [[[ UITableViewCell alloc] init] autorelease];
        }
        cell.textLabel.text = @"Please Wait...";
        cell.textLabel.font = [ UIFont boldSystemFontOfSize:17 ];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        cell.textLabel.textColor = [ UIColor whiteColor ];
        return cell;
    }
    else if ( [ self.schedule count ] == 0 ) 
    {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:
                                 @"plain_cell"];
        if (cell == nil) 
        {
            cell = [[[ UITableViewCell alloc] init] autorelease];
        }
        cell.textLabel.text = @"Schedule Not Available...";
        cell.textLabel.font = [ UIFont boldSystemFontOfSize:17 ];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        cell.textLabel.textColor = [ UIColor whiteColor ];
        return cell;
    }
    else 
    {
        int row = [ indexPath row ];
        
        NSDictionary *item = [ self.schedule objectAtIndex:row ];
        
        NSString *city = [ item objectForKey:@"city" ];
        NSString *eventdate = [ item objectForKey:@"eventdate" ];
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:
                                 @"plain_cell"];
        if (cell == nil) 
        {
            cell = [[[ UITableViewCell alloc] init] autorelease];
        }
        cell.textLabel.text = [ NSString stringWithFormat:@"%@ / %@", city, eventdate ];
        cell.textLabel.font = [ UIFont boldSystemFontOfSize:17 ];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        cell.textLabel.textColor = [ UIColor whiteColor ];
        return cell;
    }
}

#pragma mark - button callbacks...


-(IBAction) buttonBackClicked:(id)sender
{
    [ self dismissModalViewControllerAnimated:YES ];
}

#pragma mark - djcapi...

-(void) apiLoadingFailed:(NSString *)errMsg
{
    [ Utility AlertAPICallFailedWithMessage:errMsg];
}

-(void) got_schedule:(NSDictionary *)data
{
    NSNumber *_status = [ data objectForKey:@"status" ];
    NSInteger status = [ _status integerValue ];
    if ( status>0 )
    {
        self.tv.hidden = NO;
        self.activity.hidden = YES;
        NSMutableArray *sched = [ data objectForKey:@"results" ];
        self.schedule = sched;
        [self.tv reloadData];
    }
    else
    {
        NSString *msg = [ data objectForKey:@"msg" ];
        [ Utility AlertMessage:msg ];
    }
}

@end
