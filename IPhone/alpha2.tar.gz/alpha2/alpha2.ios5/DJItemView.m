//
//  DJItemView.m
//  alpha2
//
//  Created by George Williams on 12/23/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "DJItemView.h"
#import "alpha2AppDelegate.h"
#import "Utility.h"

@implementation DJItemView

@synthesize tv=_tv;
@synthesize dj=_dj;
@synthesize activity=_activity;
@synthesize label_title=_label_title;
@synthesize image_pic=_image_pic;
@synthesize cell_title=_cell_title;
@synthesize cell_web_site=_cell_web_site;
@synthesize cell_follow=_cell_follow;
@synthesize cell_schedule=_cell_schedule;
@synthesize api=_api;
@synthesize getdj=_getdj;
@synthesize cell_similar=_cell_similar;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) 
    {
        // Custom initialization
    }
    return self;
}

-(id)init
{
    return [ self initWithNibName:@"DJItemView" bundle:nil ];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    self.tv.delegate = self;
    self.tv.dataSource = self;
    //[ self.tv reloadData ];
    
    
    self.api = [ [ [ DJCAPI alloc ] init:self ] autorelease ];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.tv.hidden = YES;
    self.activity.hidden = NO;
    
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if ( self.getdj != nil )
    {
        if ( ! [ self.api get_dj:self.getdj ] )
        {
            [ Utility AlertAPICallFailed ];
        }
    }
    else
    {
        self.tv.hidden = NO;
        self.activity.hidden = YES;
        [ self.tv reloadData ];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void) dealloc
{
    self.dj = nil;
    self.api = nil;
    self.getdj = nil;
    
    [ super dealloc ];
}

#pragma mark - uitableview delegate...


#pragma mark - table view delegates...


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if ( self.dj == nil )
    {
        return 0;
    }
    else
    {
        return 4;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    int section = [ indexPath section ];
    
    if ( section == 0 )
    {
        NSString *name = self.dj.name;
        
        //  Set title...
        self.label_title.text = name;
        
        //  Set pic...
        //NSURL *url = [ NSURL URLWithString:self.event.pic_path ];
        //NSData *data = [ NSData dataWithContentsOfURL:url ];
        //UIImage *img = [ UIImage imageWithData:data ];
        //[ self.pic setImage:img ];
        
        UIImage *img = [ UIImage imageNamed:@"Genericthumb2.png" ];
        [ self.image_pic setImage:img ];
        
        self.cell_title.selectionStyle = UITableViewCellSelectionStyleNone;
        return self.cell_title;
    }
    else if ( section == 1 )
    {
        self.cell_schedule.selectionStyle = UITableViewCellSelectionStyleNone;
        return self.cell_schedule;
    }
    else if ( section == 2 )
    {
        self.cell_follow.selectionStyle = UITableViewCellSelectionStyleNone;
        return self.cell_follow;
    }
    else if ( section == 3 )
    {
        self.cell_similar.selectionStyle = UITableViewCellSelectionStyleNone;
        return self.cell_similar;
    }
    else if ( section == 4 )
    {
        return nil;
    }
    else if ( section == 5 )
    { 
        return nil;
    }
    else
    {
        return nil;
    }
    
}


- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    int section = [ indexPath section ];
    
    if ( section == 0)
    {
        return 88.0f;
    }
    else
    {
        return 44.0f;
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [ tableView deselectRowAtIndexPath:indexPath animated:YES ];
    
    int section = [ indexPath section ];
    
    if ( section == 1 )
    {
#if 0
        //  Get individual performers...
        NSString *performer = self.event.performers;
        
        NSArray *arr = [ performer componentsSeparatedByString:@";" ];
        
        //  Sanitize and validate...
        NSMutableArray *narr = [ [ NSMutableArray alloc ] initWithCapacity:0 ];
        for (int i=0;i<[arr count];i++)
        {
            NSString *item = [ arr objectAtIndex:i];
            NSString *titem = [item stringByTrimmingCharactersInSet:
                               [NSCharacterSet whitespaceAndNewlineCharacterSet  ]];
            if ( [ titem length ] == 0 )
            {
                continue;
            }
            [ narr addObject:titem ];
        }
        if ( ( narr==nil) || ( [narr count]==0) )
        {
            [ Utility AlertMessage:@"No one can be followed at this time." ];
            [ narr release ];
        }
        else
        {    
            self.follow_view = [ [ [ FollowView alloc ] init ] autorelease ]; //ANA
            self.follow_view.event = self.event;
            self.follow_view.djs = narr;
            [ narr release ];
            [ self presentModalViewController:self.follow_view animated:YES ];
        }
#endif
    }
}

#pragma mark - button callbacks...


-(IBAction) showWebSiteClicked:(id)sender
{
}

-(IBAction) showScheduleClicked:(id)sender
{
    alpha2AppDelegate * app = ( alpha2AppDelegate *) [ [ UIApplication sharedApplication ] delegate ];
    [ app showDJSchedule:self:self.dj];
}

-(IBAction) backButtonClicked: (id)sender
{
    [ self dismissModalViewControllerAnimated:YES ];
}

-(IBAction) followButtonClicked:(id)sender
{
    alpha2AppDelegate *app = (alpha2AppDelegate *)
        [ [ UIApplication sharedApplication ] delegate ];
    NSString *tokstr = app.devtoken;
    
    NSMutableArray *arr = [ [ NSMutableArray alloc ] initWithCapacity:0];
    NSMutableArray *arrids = [ [ NSMutableArray alloc ] initWithCapacity:0];
    
    [ arr addObject:self.dj.name ];
    [ arrids addObject:self.dj.djid ];
     
    if ( ! [ self.api followdjs:tokstr:arr:arrids ] )
    {
        [ Utility AlertAPICallFailed ];
    } 
    
    [ arr release ];
    [ arrids release ];
}


-(IBAction) similarButtonClicked:(id)sender
{
    alpha2AppDelegate *app = (alpha2AppDelegate *)
    [ [ UIApplication sharedApplication ] delegate ];
    
    [ app showSimilarDJS:self :self.dj ];
    
    //NSString *tokstr = app.devtoken;
    //if ( ! [ self.api similardjs: self.dj.djid ] )
    //{
    //    [ Utility AlertAPICallFailed ];
    //} 
}


#pragma mark - djcapi...

-(void) apiLoadingFailed:(NSString *)errMsg
{
    [ Utility AlertAPICallFailedWithMessage:errMsg ];
}

-(void) followed_djs:(NSDictionary *)data
{
    NSNumber *_st = [ data objectForKey:@"status" ];
    NSInteger st = [ _st integerValue ];
    if (st<=0)
    {
        NSString *msg = [ data objectForKey:@"msg" ];
        [ Utility AlertMessage:msg ];
    }
    else
    {
        NSString *msg = [ data objectForKey:@"msg" ];
        [ Utility AlertMessage:msg ];
    }
    
    //[ self dismissModalViewControllerAnimated:YES ];
}

-(void) got_dj:(NSDictionary *)data
{
    NSNumber *_st = [ data objectForKey:@"status" ];
    NSInteger st = [ _st integerValue ];
    if (st<=0)
    {
        NSString *msg = [ data objectForKey:@"msg" ];
        [ Utility AlertMessage:msg ];
    }
    else
    {
        NSMutableDictionary *dct = [ data objectForKey:@"results" ];
        
        DJ *dj = [ [ DJ alloc ] init ];
        [ dj autorelease ];
        dj.name = [ dct objectForKey:@"name" ];
        dj.djid = [ dct objectForKey:@"id" ];
        self.dj = dj;
        self.getdj = nil;
        
        self.tv.hidden = NO;
        self.activity.hidden = YES;
        [ self.tv reloadData ];
    }
}


@end
