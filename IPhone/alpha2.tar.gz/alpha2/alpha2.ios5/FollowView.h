//
//  FollowView.h
//  alpha2
//
//  Created by George Williams on 12/14/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Event.h"
#import "DJCAPI.h"

@protocol FollowViewDelegate
@optional -(void) FollowViewOK:(NSMutableArray *)djs;
@end

@interface FollowView : UIViewController
    < UITableViewDataSource, UITableViewDelegate, DJCAPIServiceDelegate >
{
    
}

//  IBOUTLET...
@property (nonatomic, retain) IBOutlet UITableView *tv;

//  RETAIN...
@property (nonatomic, retain) Event *event;
//@property (nonatomic, retain) NSArray *djs;
@property (nonatomic, retain) DJCAPI *api;

//  ASSIGN...
@property (nonatomic, assign) id<FollowViewDelegate> delegate;

//  PUBLIC FUNC...
-(IBAction) cancelClicked:(id)sender;
-(IBAction) okClicked:(id)sender;

@end
