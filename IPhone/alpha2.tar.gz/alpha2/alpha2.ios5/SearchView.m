//
//  SecondViewController.m
//  alpha2
//
//  Created by George Williams on 11/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SearchView.h"
#import "Utility.h"
#import "alpha2AppDelegate.h"

@implementation SearchView

@synthesize tv=_tv;
@synthesize cities=_cities;


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    alpha2AppDelegate *app = (alpha2AppDelegate *)[ [ UIApplication sharedApplication ] delegate];
    app.search_view = self;
    
    [ self.tv setDelegate:self ];
    [ self.tv setDataSource:self ];    
    self.cities = [ [ [ NSMutableArray alloc ] 
                   initWithObjects:
                   @"Amsterdam",
                   @"Berlin",
                   @"Bologna",
                   @"Beirut",
                   @"Buenos Aires",
                   @"Camboriu",
                   @"Ciauba",
                   @"Dallas",
                   @"Delhi",
                   @"Florence",
                   @"Goa",
                   @"Hamptons",
                   @"Ibiza",
                   @"Las Vegas",
                   @"Leuven",
                   @"London", 
                   @"Long Island City",
                   @"Los Angeles",
                   @"Madrid",
                   @"Manchester",
                   @"Miami",
                   @"Montreal",
                   @"Moscow",
                   @"Mumbai",
                   @"Mykonos",
                   @"New York City",
                   @"Paris",
                   @"Punta del Este",
                   @"San Diego",
                   @"Sharm El-Sheik",
                   @"Singapore",
                   @"Tokyo",
                   @"Toronto",
                     nil] autorelease ]; //ANA                 
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload
{
    [super viewDidUnload];

    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    //[ Utility AlertMessage:@"This is not yet implemented" ];
}

-(void) viewWillAppear:(BOOL)animated
{
    [ self.tv reloadData ];

}



- (void)dealloc
{
    self.cities = nil;
    [super dealloc];
}


#pragma mark - table view delegates...


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [ self.cities count ];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:
                             @"search_cell"];
    int row = [ indexPath row ];
    if (cell == nil) 
    {
        cell = [[[ UITableViewCell alloc] init] autorelease];
    }
    
    [ cell.textLabel setText: [ self.cities objectAtIndex:row ] ];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.textColor = [ UIColor whiteColor ];
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    alpha2AppDelegate *app = (alpha2AppDelegate *)[ [ UIApplication sharedApplication ] delegate];

    [ self.tv deselectRowAtIndexPath:indexPath animated:YES];
    
    UITableViewCell *cell = [ self.tv cellForRowAtIndexPath:indexPath ];
    NSString *city = cell.textLabel.text;
    [ app doSearch:self:city];
   
}
/*
- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
}
 */

#pragma mark - button callbacks...


-(IBAction) buttonBackClicked:(id)sender
{
    [ self dismissModalViewControllerAnimated:YES ];
}


@end
