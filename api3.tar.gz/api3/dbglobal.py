#
# Configuration...
#
DBNAME = "djcorner3"

