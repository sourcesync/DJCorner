:mod:`dbref` -- MOVED
=====================

.. module:: pymongo.dbref

This module has been deprecated in favor of :mod:`bson.dbref`. Please
use that module instead.

.. versionchanged:: 1.9
   Deprecated.
