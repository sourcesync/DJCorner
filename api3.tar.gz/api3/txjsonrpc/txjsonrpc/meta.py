display_name = "txJSON-RPC"
library_name = "txjsonrpc"
version = "0.3"
author = "Duncan McGreggor"
author_email = "oubiwann@adytum.us"
license = "BSD, GPL"
url = "http://launchpad.net/%s" % library_name
description = "Code for creatig Twisted JSON-RPC servers and clients."
