. ./admin/defs.sh

find . -name "*pyc" -exec rm {} \;
cleanup
