. ./admin/defs.sh
echo "Changes:"
getDiff ChangeLog
echo
bzr stat
