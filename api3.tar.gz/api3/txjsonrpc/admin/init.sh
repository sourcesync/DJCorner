. ./admin/defs.sh
bzr init
bzr push $BZR
bzr bind $BZR
bzr cia-project $NAME
