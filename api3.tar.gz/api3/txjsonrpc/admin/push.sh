. ./admin/defs.sh

pushLaunchpad || error
